-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


local BusinessFront = require("BusinessFront")
local data          = require("includes.data.sv23_data")

---@class SYOpts : BusinessFrontOpts

-- Class representing the SalvageYard business.
---@class SalvageYard : BusinessFront
---@field private m_id integer
---@field private m_name string
---@field private m_safe CashSafe
---@field private m_bring_veh_triggered boolean
local SalvageYard   = setmetatable({}, BusinessFront)
SalvageYard.__index = SalvageYard

---@param opts SYOpts
---@return SalvageYard
function SalvageYard.new(opts)
	local base = BusinessFront.new(opts) ---@cast base SalvageYard
	return setmetatable(base, SalvageYard)
end

function SalvageYard:Reset() --[[noop]] end

---@return boolean
function SalvageYard:HasStaffUpgrade()
	return stats.get_int("MPX_SALVAGE_YARD_STAFF") == 1
end

---@return boolean
function SalvageYard:HasWallSafeUpgrade()
	return stats.get_int("MPX_SALVAGE_YARD_WALL_SAFE") == 1
end

---@param slot integer
---@return boolean
function SalvageYard:IsLiftTaken(slot)
	return self:GetSalvageModelOnLift(slot) ~= 0
end

function SalvageYard:IsTowMissionActive()
	return script.is_active("fm_content_tow_truck_work")
end

---@return boolean
function SalvageYard:IsRobberyActive()
	return self:GetRobberyType() >= 0
end

function SalvageYard:IsWeeklyCooldownDisabled()
	return tunables.get_int("SALV23_VEH_ROBBERY_WEEK_ID") ~= stats.get_int("MPX_SALV23_WEEK_SYNC")
end

---@return boolean
function SalvageYard:ArePrepsCompleted()
	return Bit.IsBitSet(stats.get_int("MPX_SALV23_GEN_BS"), 0)
end

-- Similar to nightclub popularity.
---@return integer `0 .. 100`
function SalvageYard:GetIncomeThreshold()
	return stats.get_packed_stat_int(51051)
end

---@param slot integer
---@return hash
function SalvageYard:GetSalvageModelOnLift(slot)
	return stats.get_int(_F("MPX_MPSV_MODEL_SALVAGE_LIFT%d", slot))
end

---@param slot integer
---@return integer
function SalvageYard:GetSalvageValueOnLift(slot)
	return stats.get_int(_F("MPX_MPSV_VALUE_SALVAGE_LIFT%d", slot))
end

---@param slot integer
---@return integer
function SalvageYard:GetRobberyCarValue(slot)
	return stats.get_int(_F("MPX_SAL23_VALUE_VEH%d", slot))
end

---@param slot integer
---@return string
function SalvageYard:GetWeeklyRobberyStatus(slot)
	local status = stats.get_int(_F("MPX_SALV23_VEHROB_STATUS%d", slot))
	return _T(data.robbery_status_labels[status + 1] or "GENERIC_UNKNOWN")
end

---@return string
function SalvageYard:GetRobberyCooldownString()
	local cd = stats.get_int("MPX_SALV23_VEHROB_CD")
	return cd <= 0 and _T("SY_CD_NONE") or _T("SY_CD_ACTIVE")
end

function SalvageYard:GetRobberyType()
	return stats.get_int("MPX_SALV23_VEH_ROB")
end

---@return string
function SalvageYard:GetRobberyName()
	local stringtype = data.robbery_types[self:GetRobberyType() + 1]
	return stringtype and stringtype.name or _T("GENERIC_NONE")
end

---@return hash
function SalvageYard:GetRobberyVehicleModel()
	return stats.get_int("MPX_SALV23_VEH_MODEL")
end

---@return string
function SalvageYard:GetRobberyVehicleName()
	return Game.GetVehicleDisplayName(self:GetRobberyVehicleModel())
end

---@return integer
function SalvageYard:GetRobberyValue()
	return stats.get_int("MPX_SALV23_SALE_VAL")
end

---@return boolean
function SalvageYard:GetRobberyKeepState()
	return stats.get_bool("MPX_SALV23_CAN_KEEP")
end

---@param slot integer
---@return string
function SalvageYard:GetRobberyCarInSlot(slot)
	local index = stats.get_int(_F("MPX_MPSV_MODEL_SALVAGE_VEH%d", slot))
	return data.vehicle_targets[index]
end

---@param toggle boolean
---@param silent? boolean
function SalvageYard:ToggleWeeklyCooldown(toggle, silent)
	local weekID = stats.get_int("MPX_SALV23_WEEK_SYNC")
	tunables.set_int("SALV23_VEH_ROBBERY_WEEK_ID", toggle and weekID + 1 or weekID)
	if (toggle and not silent) then
		Notifier:ShowSuccess("Salvage Yard", _T("SY_CD_SKIP_SUCCESS"))
	end
end

function SalvageYard:SkipPreps()
	local current = self:GetRobberyType()
	local info = data.robbery_types[current + 1]
	if (not info) then
		Notifier:ShowError("Salvage Yard", _T("SY_CD_ROB_TYPE_ERR"))
		return
	end

	stats.set_int("MPX_SALV23_FM_PROG", info.fm_prog)
	stats.set_int("MPX_SALV23_SCOPE_BS", info.scope_bs)
	stats.set_int("MPX_SALV23_DISRUPT", info.disrupt)
	Notifier:ShowSuccess("Salvage Yard", _T("SY_PREP_SKIP"))
end

function SalvageYard:DoubleCarWorth()
	local current_worth = self:GetRobberyValue()
	stats.set_int("MPX_SALV23_SALE_VAL", current_worth * 2)
end

function SalvageYard:MaximizeIncome()
	if (self:GetIncomeThreshold() >= 100) then
		return
	end

	stats.set_packed_stat_int(51051, 100)
end

function SalvageYard:LockIncomeDecay()
	if (tunables.get_int(797544186) <= 0) then
		return
	end

	tunables.set_int(797544186, 0)
	self:MaximizeIncome()
end

function SalvageYard:RestoreIncomeDecay()
	if (tunables.get_int(797544186) == 5) then
		return
	end

	tunables.set_int(797544186, 5)
end

---@param toggle boolean
function SalvageYard:ToggleIncomeDecay(toggle)
	if (toggle) then
		self:LockIncomeDecay()
	else
		self:RestoreIncomeDecay()
	end
end

---@return seconds
function SalvageYard:GetSalvagePosixForLift(slot)
	if (not self:IsLiftTaken(slot)) then
		return 0
	end

	return stats.get_int(_F("MPX_SALVAGING_POSIX_LIFT%d", slot))
end

---@return boolean
function SalvageYard:IsBringingTowMissionTarget()
	return self.m_bring_veh_triggered == true
end

function SalvageYard:BringTowMissionTarget()
	if (self.m_bring_veh_triggered) then
		return
	end

	self.m_bring_veh_triggered = true
	ThreadManager:Run(function()
		-- This is low quality but works... kinda.
		-- The proper way to do it is either just instantly finish the mission in the script thread or check the mission flow bitset
		-- then get the target vehicle from there but I'm lazy and don't want to maintain any more script globals and locals.
		--
		--  [b3788.0]:
		-- 	  - FMCTTW        = ScriptLocal(1850, "fm_content_tow_truck_work"):At(48)
		-- 	  - TargetVehicle = FMCTTW:At(0, 9) -- (netID)
		-- 	  - Towtruck      = FMCTTW:At(1, 9) -- (netID)
		--

		if (not self:IsTowMissionActive()) then
			self.m_bring_veh_triggered = false
			return
		end

		if (not LocalPlayer:IsHostOfScript("fm_content_tow_truck_work")) then
			Notifier:ShowError(_T("SY_SALVAGE_YARD"), _T("YRV3_SCRIPT_HOST_ERR"))
			self.m_bring_veh_triggered = false
			return
		end

		local PV = LocalPlayer:GetVehicle()
		if (LocalPlayer:IsOnFoot() or not PV:IsTowTruck()) then
			Notifier:ShowError(_T("SY_SALVAGE_YARD"), _T("SY_NOT_IN_TOWTRUCK_ERR"))
			self.m_bring_veh_triggered = false
			return
		end

		local found, objectiveCoords = Game.GetObjectiveBlipCoords()
		if (not found or not objectiveCoords or objectiveCoords:is_zero()) then
			Notifier:ShowError(_T("SY_SALVAGE_YARD"), _T("SY_TOW_OBJECTIVE_NOT_FOUND_ERR"))
			self.m_bring_veh_triggered = false
			return
		end

		local towTruck     = PV:GetHandle()
		local objectiveVeh = Game.GetClosestVehicle(objectiveCoords, 1, towTruck, true, 0)
		if (objectiveVeh == 0 or not ENTITY.IS_ENTITY_A_VEHICLE(objectiveVeh)) then
			Notifier:ShowError(_T("SY_SALVAGE_YARD"), _T("SY_TOW_VEH_NOT_FOUND_ERR"))
			self.m_bring_veh_triggered = false
			return
		end

		local myHandle  = LocalPlayer:GetHandle()
		local myPos     = LocalPlayer:GetPos()
		local heading   = LocalPlayer:GetHeading()
		local bonePos   = PV:GetBonePosition("tow_mount_a")
		local fwdVec    = PV:GetForwardVector()
		local offsetPos = vec3:new(
			bonePos.x - fwdVec.x * 3.5,
			bonePos.y - fwdVec.y * 3.5,
			bonePos.z
		)

		if (myPos:distance(objectiveCoords) >= 100) then
			-- update the objective without touching any script locals then jump back to our previous position
			PED.SET_PED_COORDS_KEEP_VEHICLE(myHandle, objectiveCoords.x, objectiveCoords.y, objectiveCoords.z)
			yield()
			PED.SET_PED_COORDS_KEEP_VEHICLE(myHandle, myPos.x, myPos.y, myPos.z)
			VEHICLE.SET_VEHICLE_ON_GROUND_PROPERLY(towTruck, 5.0)
		end

		VEHICLE.SET_VEHICLE_TOW_TRUCK_ARM_POSITION(towTruck, 0.0)
		sleep(2000)
		ENTITY.SET_ENTITY_HEADING(objectiveVeh, heading)
		ENTITY.SET_ENTITY_PROOFS(
			objectiveVeh,
			false,
			false,
			false,
			true, -- collision proof so it doesn't yeet itself when we bring it
			false,
			false,
			false,
			false
		)
		Game.SetEntityCoords(objectiveVeh, offsetPos)
		while (Game.GetEntityCoords(objectiveVeh, false):distance(offsetPos) > 50) do
			yield()
		end

		VEHICLE.SET_VEHICLE_ON_GROUND_PROPERLY(objectiveVeh, 5.0)
		if (not ENTITY.IS_ENTITY_ATTACHED_TO_ENTITY(objectiveVeh, towTruck)) then
			VEHICLE.ATTACH_VEHICLE_TO_TOW_TRUCK(towTruck, objectiveVeh, false, 0, 0, 0)
			sleep(500)
		end

		VEHICLE.SET_VEHICLE_TOW_TRUCK_ARM_POSITION(towTruck, 1.0)

		-- teleport to the salvage yard to complete the mission
		---@diagnostic disable
		local syPos = self:GetCoords()
		if (LocalPlayer:GetPos():distance(syPos) > 10) then
			LocalPlayer:Teleport(syPos, true)
			---@diagnostic enable

			sleep(2000)
			if (LocalPlayer:IsOutside() and not CAM.IS_SCREEN_FADING_OUT() and not CAM.IS_SCREEN_FADED_OUT() and not CAM.IS_SCREEN_FADING_IN()) then
				if (not ENTITY.IS_ENTITY_ATTACHED_TO_ENTITY(objectiveVeh, towTruck)) then
					VEHICLE.SET_VEHICLE_ON_GROUND_PROPERLY(objectiveVeh, 5.0)
					VEHICLE.SET_ATTACHED_VEHICLE_TO_TOW_TRUCK_ARM_(towTruck, objectiveVeh)
				end
			end
		end

		self.m_bring_veh_triggered = false
	end)
end

---@param slot integer
function SalvageYard:SalvageNow(slot)
	if (not self:IsLiftTaken(slot)) then
		return
	end

	local diff     = self:HasStaffUpgrade() and 2880 or 5760
	local statName = _F("MPX_SALVAGING_POSIX_LIFT%d", slot)
	stats.set_int(statName, stats.get_int(statName) - diff)
end

---@return integer
function SalvageYard:GetEstimatedIncome()
	local sum = 0

	for i = 1, 2 do
		sum = sum + self:GetSalvageValueOnLift(i)
	end

	for i = 1, 4 do
		sum = sum + self:GetRobberyCarValue(i)
	end

	return sum + self.m_safe:GetCashValue()
end

ThreadManager:Run(function()
	local array = data.vehicle_targets
	for i = 1, #array do
		local model = array[i]
		array[i]    = Game.GetVehicleDisplayName(model)
	end
end)

return SalvageYard.new
