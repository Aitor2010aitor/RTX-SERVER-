-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


local FeatureBase = require("includes.modules.FeatureBase")

---@class WorldMisc : FeatureBase
---@field private m_entity World
---@field private m_active boolean
---@field public m_bounds_extended boolean	-- bad idea. should've used a shared state instead of juggling bools
---@field public m_ocean_waves_disabled boolean
---@field public m_flight_music_disabled boolean
---@field public m_wanted_music_disabled boolean -- well now I'm too deep. fml
local WorldMisc = setmetatable({}, FeatureBase)
WorldMisc.__index = WorldMisc

---@param ent any
---@return WorldMisc
function WorldMisc.new(ent)
	local self = FeatureBase.new(ent)
	---@diagnostic disable-next-line
	return setmetatable(self, WorldMisc)
end

function WorldMisc:Init()
	self.m_active                = false
	self.m_bounds_extended       = false
	self.m_ocean_waves_disabled  = false
	self.m_flight_music_disabled = false
	self.m_wanted_music_disabled = false
end

function WorldMisc:ShouldRun()
	return not Game.IsPlayerSwitchInProgress() and not script.is_active("maintransition")
end

function WorldMisc:Cleanup()
	self.m_entity:ResetBounds()
	self.m_entity:ResetOceanWaves()
	AUDIO.SET_AUDIO_FLAG("DisableFlightMusic", false)
	AUDIO.SET_AUDIO_FLAG("WantedMusicDisabled", false)

	self.m_bounds_extended       = false
	self.m_ocean_waves_disabled  = false
	self.m_flight_music_disabled = false
	self.m_wanted_music_disabled = false
end

function WorldMisc:Update()
	local worldInst = self.m_entity
	local config    = GVars.features.world
	if (config.extend_bounds and not self.m_bounds_extended) then
		worldInst:ExtendBounds()
		self.m_bounds_extended = true
	end

	if (config.disable_ocean_waves and not self.m_ocean_waves_disabled) then
		worldInst:DisableOceanWaves()
		self.m_ocean_waves_disabled = true
	end

	if (config.disable_flight_music and not self.m_flight_music_disabled) then
		AUDIO.SET_AUDIO_FLAG("DisableFlightMusic", true)
		self.m_flight_music_disabled = true
	end

	if (config.disable_wanted_music and not self.m_wanted_music_disabled) then
		AUDIO.SET_AUDIO_FLAG("WantedMusicDisabled", true)
		self.m_wanted_music_disabled = true
	end
end

return WorldMisc
