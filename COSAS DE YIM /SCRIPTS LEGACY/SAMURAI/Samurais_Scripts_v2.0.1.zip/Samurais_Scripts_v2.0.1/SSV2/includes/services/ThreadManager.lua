-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


---@diagnostic disable: lowercase-global
local API_VER <const> = Backend:GetGameBranch()

---@enum eThreadState
eThreadState = {
	UNK       = -1,
	DEAD      = 0,
	RUNNING   = 1,
	SUSPENDED = 2,
}

---@enum eInternalThreadState
eInternalThreadState = {
	NORMAL     = 0,
	STALLED    = 1,
	HUNG       = 2,
	BURSTING   = 3,
	TOO_FAST   = 4,
	TOO_SLOW   = 5,
	STARVED    = 5,
	DEADLOCKED = 5,
}

---@enum eThreadStage
eThreadStage = {
	IDLE          = 0,
	PRE_CALLBACK  = 1,
	POST_CALLBACK = 2,
}

--#region Thread

--------------------------------------
-- Class: Thread
--------------------------------------
---@ignore
---@class Thread : ClassMeta<Thread>
---@field private m_name string
---@field private m_callback function
---@field private m_can_run boolean
---@field private m_should_pause boolean
---@field private m_should_terminate boolean
---@field private m_state eThreadState
---@field private m_stage eThreadStage
---@field private m_time_created TimePoint
---@field private m_time_started seconds
---@field private m_last_entry_at seconds
---@field private m_last_exit_at seconds
---@field private m_last_yield_at seconds
---@field private m_avg_work_ms milliseconds
---@field private m_avg_cycle_ms milliseconds
---@field private m_exc_handler? fun(msg?: string)
---@overload fun(name: string, callback: function, exceptionHandler?: fun(msg?: string)): Thread
local Thread = Class("Thread")

---@param name string
---@param callback function
---@param exceptionHandler? fun(msg?: string)
function Thread.new(name, callback, exceptionHandler)
	if (not string.isvalid(name)) then
		name = string.random(5, true):upper()
	end

	return setmetatable({
		m_name          = name,
		m_callback      = callback,
		m_exc_handler   = exceptionHandler,
		m_can_run       = false,
		m_should_pause  = false,
		m_wants_exit    = false,
		m_state         = eThreadState.UNK,
		m_stage         = eThreadStage.IDLE,
		m_time_created  = TimePoint(),
		m_time_started  = 0,
		m_last_entry_at = 0,
		m_last_exit_at  = 0,
		m_last_yield_at = 0,
		m_avg_work_ms   = 0,
		m_avg_cycle_ms  = 0,
		---@diagnostic disable-next-line: param-type-mismatch
	}, Thread)
end

---@return string
function Thread:GetName()
	return self.m_name
end

---@return eThreadState
function Thread:GetState()
	return self.m_state
end

---@private
---@return eThreadStage
function Thread:GetStage()
	return self.m_stage
end

---@return function
function Thread:GetCallback()
	return self.m_callback
end

---@return fun(msg?: string)?
function Thread:GetExceptionHandler()
	return self.m_exc_handler
end

---@return milliseconds
function Thread:GetTimeCreated()
	return self.m_time_created:Value()
end

---@return seconds
function Thread:GetTimeStarted()
	return self.m_time_started
end

---@return string
function Thread:GetLifetime()
	return Time.FormatSinceMillis(self:GetTimeCreated())
end

---@return string
function Thread:GetRunningTime()
	return Time.FormatSince(self:GetTimeStarted())
end

---@return boolean
function Thread:CanRun()
	return self.m_can_run and type(self.m_callback) == "function"
end

---@return boolean
function Thread:IsRunning()
	return self.m_state == eThreadState.RUNNING
end

---@return boolean
function Thread:IsSuspended()
	return self.m_state == eThreadState.SUSPENDED
end

---@param func fun(msg?: string)?
function Thread:RegisterExceptionHandler(func)
	self.m_exc_handler = func
end

---@param msg string?
function Thread:OnError(msg)
	local handler = self.m_exc_handler
	if (not handler) then return end
	pcall(handler, msg)
end

---@param s? script_util
function Thread:OnTick(s)
	self.m_can_run = (type(self.m_callback) == "function")
	if (not self.m_can_run) then
		log.fwarning("Thread %s was terminated. Nothing to execute!", self.m_name)
		self:Stop()
		return
	end

	self.m_time_started  = Time.Now()
	self.m_last_entry_at = Time.Now()
	Backend:debug("Started thread %s", self.m_name)

	while (self.m_can_run) do
		self.m_stage = eThreadStage.IDLE

		if (self.m_should_pause) then
			self.m_state         = eThreadState.SUSPENDED
			self.m_time_started  = 0
			self.m_last_entry_at = 0
			repeat
				self.m_last_yield_at = Time.Now()
				yield()
			until not self.m_should_pause or self.m_should_terminate
			self.m_time_started  = Time.Now()
			self.m_last_entry_at = Time.Now()
		end

		if (self.m_should_terminate) then
			self:Stop()
			return
		end

		self.m_state         = eThreadState.RUNNING
		local cycle_start    = Time.Now()
		self.m_last_entry_at = cycle_start
		local work_start     = cycle_start
		self.m_stage         = eThreadStage.PRE_CALLBACK
		local ok, err        = pcall(self.m_callback, s)
		self.m_stage         = eThreadStage.POST_CALLBACK
		local work_end       = Time.Now()
		local work_ms        = (work_end - work_start) * 1000
		self.m_avg_work_ms   = self.m_avg_work_ms * 0.9 + work_ms * 0.1

		if (self.m_should_terminate or not ok) then
			if (not ok and err) then
				local msg = _F("Thread %s was terminated due to an exception: %s", self.m_name, err)
				log.warning(msg)
				self:OnError(msg)
			end

			self:Stop()
			return
		end

		self.m_last_exit_at  = Time.Now()
		self.m_last_yield_at = self.m_last_exit_at
		local cycle_ms       = (self.m_last_exit_at - cycle_start) * 1000
		self.m_avg_cycle_ms  = self.m_avg_cycle_ms * 0.9 + cycle_ms * 0.1
		yield()
	end
end

---@return boolean
function Thread:Start()
	if (self.m_state == eThreadState.DEAD or self.m_state == eThreadState.UNK) then
		return false
	end

	self.m_can_run = (type(self.m_callback) == "function")
	if (not self.m_can_run) then
		log.fwarning("Thread %s was terminated. Nothing to execute.", self.m_name)
		self.m_state = eThreadState.DEAD
		return false
	end

	self.m_state        = eThreadState.RUNNING
	self.m_time_started = Time.Now()
	Backend:debug("Started thread %s", self.m_name)
	return true
end

function Thread:Stop()
	if (self.m_state == eThreadState.UNK or self.m_state == eThreadState.DEAD) then
		return
	end

	if (self.m_stage ~= eThreadStage.IDLE) then
		self.m_should_terminate = true
		return
	end

	self.m_time_started     = 0
	self.m_can_run          = false
	self.m_should_terminate = false
	self.m_state            = eThreadState.DEAD
	self.m_stage            = eThreadStage.IDLE
	Backend:debug("Terminated thread %s", self.m_name)
end

function Thread:Suspend()
	self.m_time_started = 0
	self.m_should_pause = true
end

function Thread:Resume()
	self.m_should_pause = false
	self.m_time_started = Time.Now()
end

---@return eInternalThreadState
function Thread:GetInternalState()
	local now = Time.Now()

	if (now - self.m_last_entry_at > 5.0) then
		return eInternalThreadState.STALLED
	end

	if (now - self.m_last_exit_at > 2.0) then
		return eInternalThreadState.STARVED
	end

	if (self.m_avg_cycle_ms < 0.02) then
		return eInternalThreadState.TOO_FAST
	end

	if (self.m_avg_work_ms < 0.1) then
		return eInternalThreadState.BURSTING
	end

	return eInternalThreadState.NORMAL
end

---@return milliseconds
function Thread:GetLoadAvg()
	if (self.m_avg_cycle_ms == 0) then
		return 0
	end

	return self.m_avg_work_ms / self.m_avg_cycle_ms
end

--#endregion


--#region ThreadManager

-- TODO: state-bucketed refactor: split m_threads into separate tables by state
-- (RUNNING/SUSPENDED/DEAD/UNK) for faster bulk operations in high thread count use cases

---------------------------------------
-- Class: ThreadManager
---------------------------------------
---@class ThreadManager : ClassMeta<ThreadManager>
---@field private m_threads table<string, Thread>
---@field private m_mock_routines table<integer, thread>
---@field private m_callback_handlers table<integer, { dispatch: function }>
---@field protected m_initialized boolean
---@overload fun() : ThreadManager
local ThreadManager = Class("ThreadManager")

local mock_routines = {}

---@return ThreadManager
function ThreadManager:init()
	if (self.m_initialized) then return self end
	if (_G.ThreadManager) then return _G.ThreadManager end

	local instance = setmetatable({
		m_threads           = {},
		m_callback_handlers = {
			[Enums.eGameBranch.MOCK] = {
				dispatch = function(callback)
					table.insert(
						mock_routines,
						coroutine.create(callback)
					)
				end
			},
			[Enums.eGameBranch.LEGACY] = {
				dispatch = function(callback)
					script.run_in_fiber(function(s)
						callback(s)
					end)
				end
			},
			[Enums.eGameBranch.ENHANCED] = {
				dispatch = function(callback)
					script.run_in_fiber(function(s)
						callback(s)
					end)
				end

				-- Support for YimMenuV2 is no longer considered
				-- dispatch = function(callback)
				-- 	---@diagnostic disable-next-line: undefined-field
				-- 	script.run_in_callback(function(s)
				-- 		callback(s)
				-- 	end)
				-- end
			}
		}
		---@diagnostic disable-next-line
	}, ThreadManager)

	instance.m_mock_routines = mock_routines

	Backend:RegisterEventCallback(Enums.eBackendEvent.RELOAD_UNLOAD, function()
		instance:Shutdown()
	end)

	instance.m_initialized = true
	return instance
end

-- Runs a callback once in a fiber.
---@param func fun(s?: script_util)
function ThreadManager:Run(func)
	if (type(func) ~= "function") then
		Backend:debug("[ThreadManager] Invalid parameter! Expected function, got %s instead.", type(func))
		return
	end

	local handler = self.m_callback_handlers[API_VER]
	if not (handler and handler.dispatch) then
		Backend:debug("[ThreadManager] No handler for API version: %s", EnumToString(Enums.eGameBranch, API_VER))
		return
	end

	handler.dispatch(func)
end

-- Creates a thread that runs in a loop.
---@param name string
---@param func fun(s: script_util?)
---@param kwargs?  { suspended: boolean?, is_debug_thread: boolean?, exception_handler?: fun(msg?: string)? }
---@return Thread?
function ThreadManager:RegisterLooped(name, func, kwargs)
	kwargs            = kwargs or {}
	local is_mock_env = (API_VER == Enums.eGameBranch.MOCK)
	local is_debug    = kwargs.is_debug_thread or false

	if (is_mock_env and not is_debug) then return end
	if (is_debug and not is_mock_env) then return end

	if (not string.isvalid(name)) then
		name = string.random(5, true):upper()
	end

	if (self:IsThreadRegistered(name)) then
		log.fwarning("A thread with the name '%s' is already registered!", name)
		return
	end

	local thread = Thread(name, func, kwargs.exception_handler)
	if (kwargs.suspended) then thread:Suspend() end

	self.m_threads[name] = thread
	self:Run(function(s) thread:OnTick(s) end)
	return thread
end

---@return Thread
function ThreadManager:GetThread(name)
	return self.m_threads[name]
end

---@generic RET
---@param name string
---@param default RET
---@param func fun(thread: Thread, ...?: any): RET
---@param ... any
---@return RET
function ThreadManager:WithThreadName(name, default, func, ...)
	local thread = self:GetThread(name)
	if (not thread) then
		return default
	end

	return func(thread, ...)
end

---@param func fun(name: string, thread: Thread): nil
function ThreadManager:ForEach(func)
	for name, thread in pairs(self.m_threads) do
		func(name, thread)
	end
end

---@param name string
---@return eThreadState
function ThreadManager:GetThreadState(name)
	return self:WithThreadName(name, eThreadState.UNK, function(thread)
		return thread:GetState()
	end)
end

function ThreadManager:ListThreads()
	return self.m_threads
end

---@param name string
---@return boolean
function ThreadManager:IsThreadRegistered(name)
	return self.m_threads[name] ~= nil
end

---@param name string
---@return boolean
function ThreadManager:IsThreadRunning(name)
	return self:WithThreadName(name, false, function(thread)
		return thread:IsRunning()
	end)
end

-- ### This is dangerous outside of debug context. Do not call.
--
-- TODO: Refactor and properly document this.
---@private
---@param name string
function ThreadManager:RestartThread(name)
	self:WithThreadName(name, nil, function(thread)
		if (thread:IsRunning()) then
			return
		end

		-- This is horrible. Some of our modules hold references to their threads and doing this leaves them with dangling references.
		-- Thankfully this does not end up actually happening since this branch is never reached.
		-- I can't remember why I did this but I'm pretty sure it's supposed to be a duct tape fix to some obscure bug. I blame Beck's.
		if (not thread:Start()) then
			Backend:debug("Recreating thread %s", name)
			local func           = thread:GetCallback()
			local new_thread     = Thread(name, func)
			self.m_threads[name] = new_thread
			self:Run(function(s) new_thread:OnTick(s) end)
		end
	end)
end

---@param name string
function ThreadManager:SuspendThread(name)
	self:WithThreadName(name, nil, function(thread)
		thread:Suspend()
	end)
end

---@param name string
function ThreadManager:ResumeThread(name)
	self:WithThreadName(name, nil, function(thread)
		thread:Resume()
	end)
end

---@param name string
function ThreadManager:TerminateThread(name)
	self:WithThreadName(name, nil, function(thread)
		thread:Stop()
	end)
end

---@param name string
function ThreadManager:RemoveThread(name)
	self:TerminateThread(name)
	self.m_threads[name] = nil
end

function ThreadManager:SuspendAllThreads()
	self:ForEach(function(_, thread) thread:Suspend() end)
end

function ThreadManager:ResumeAllThreads()
	self:ForEach(function(_, thread) thread:Resume() end)
end

function ThreadManager:RemoveAllThreads()
	self:ForEach(function(name, _) self:RemoveThread(name) end)
	self.m_mock_routines = {}
end

function ThreadManager:Shutdown()
	self:RemoveAllThreads()
end

function ThreadManager:DebugPrint()
	if (not Backend.is_debug) then
		return
	end

	for name, thread in pairs(self.m_threads) do
		printf(
			"[%s] running: %s, suspended: %s",
			name,
			thread:IsRunning(),
			thread:IsSuspended()
		)
	end
end

function ThreadManager:UpdateMockRoutines()
	if (#self.m_mock_routines == 0) then
		return
	end

	while (API_VER == Enums.eGameBranch.MOCK) do
		for i = #self.m_mock_routines, 1, -1 do
			local co = self.m_mock_routines[i]
			if (coroutine.status(co) == "dead") then
				table.remove(self.m_mock_routines, i)
			else
				local ok, err = coroutine.resume(co)
				if (not ok) then
					Backend:debug("[Coroutine error]: %s", err)
					table.remove(self.m_mock_routines, i)
				end
			end
		end
	end
end

--#endregion

local singleInstance = ThreadManager()
_G.ThreadManager     = singleInstance
return ThreadManager()
